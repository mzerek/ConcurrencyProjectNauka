package chapter01.threadmanager.demo07_daemon;

import java.util.Date;

// �洢���¼���Ϣ
public class Event {
	// �¼���ʱ��
	private Date date;

	// �¼�����Ϣ
	private String event;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}
}
